    <!-- Vendor Start -->
    <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container py-5 mb-5">
            <div class="bg-white">
                <div class="owl-carousel vendor-carousel">
                    <img src="partner logo/jpeg-optimizer_1.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_2.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_3.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_4.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_5.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_6.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_7.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_8.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_9.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_10.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_11.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_12.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_13.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_14.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_15.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_16.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_17.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_18.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_19.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_20.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_21.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_22.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_23.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_24.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_25.jpg" alt=""> 
                    <img src="partner logo/jpeg-optimizer_26.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_27.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_28.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_29.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_30.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_31.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_32.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_33.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_34.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_35.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_36.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_37.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_38.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_39.jpg" alt="">
                    <img src="partner logo/jpeg-optimizer_40.jpg" alt="">
                         
                </div>
                 <div class="text-center mt-4">
                <p class="text-muted" style="font-size: 14px;">
                    Disclaimer: All brand logos displayed above are the property of their respective owners and are used for informational purposes only. Their inclusion does not imply endorsement or affiliation.
                </p>
            </div>
            </div>
        </div>
    </div>
    <!-- Vendor End -->
  
 <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light mt-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <!--<div class="row gx-5">-->
              
                <div class="col-lg-12 col-md-6">
                    <div class="row gx-5">
                        <div class="col-lg-5 col-md-12 pt-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Get In Touch</h3>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0"><b>Corporate Office : </b>Unit No. 1,2 & 6 Saraswati Building,
                                    Tungareshwar Industrial Complex, Sativali,
                                    Vasai Road East, Mumbai ( India) - 401 208</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-envelope-open text-primary me-2"></i>
                                <p class="mb-0">info@radcompackaging.com</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-telephone text-primary me-2"></i>
                                <p class="mb-0">+91-9579133238</p>
                            </div>
                            <div class="d-flex mt-4">
                                <a class="btn btn-primary btn-square me-2" href="https://www.twitter.com/RadcomPackaging" target="_blank"><i class="fab fa-twitter fw-normal"></i></a>
                                <a class="btn btn-primary btn-square me-2" href="https://www.facebook.com/radcompackagingpvtltd/" target="_blank"><i class="fab fa-facebook-f fw-normal"></i></a>
                                <a class="btn btn-primary btn-square me-2" href="https://www.linkedin.com/company/radcom-packaging-pvt-ltd---india" target="_blank"><i class="fab fa-linkedin-in fw-normal"></i></a>
                                <a class="btn btn-primary btn-square" href="https://www.instagram.com/radcompackaging/" target="_blank"><i class="fab fa-instagram fw-normal"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-12 pt-0 pt-lg-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">Quick Links</h3>
                            </div>
                            <div class="link-animated d-flex flex-column justify-content-start">
                                <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Home</a>
                                <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>About Us</a>
                                <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Our Services</a>
                                <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Meet The Team</a>
                                <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Latest Blog</a>
                                <a class="text-light" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Contact Us</a>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12 pt-0 pt-lg-5 mb-5">
                            <div class="section-title section-title-sm position-relative pb-3 mb-4">
                                <h3 class="text-light mb-0">REGISTERED OFFICE:</h3>
                            </div> 
                           <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0"><b>Sales Office  :</b> Delhi - NCR 1094 Hudo Colony,Sector -46,Gurugram
                                Haryana - 122 018(India)</p>
                            </div>
                          <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0"> <b>PLANT - 1  : </b> Plot No. 41, Survey No. 122/4, Paily Govt. Est., Khadoli Village Dadra & Nagar Haveli,
                                Silvassa - INDIA - 396230</p>
                            </div>
                             <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0"> <b>PLANT - 2  :</b>Plot No 28, Old Survey no 259/1/1, New Survey No.1077, Dadra Demni, Dadra,
                                Silvassa - INDIA - 396 193</p>
                            </div>
                        </div>
                    </div>
                        <div class="d-flex align-items-center justify-content-center" style="height: 75px;">
                        <p class="mb-0">&copy; <a class="text-white border-bottom" href="index.php">radcompackaging.co.in</a>. All Rights Reserved.   
						 
                    </div>
                </div>
            
            </div>
        <!--</div>-->
    </div>
      
 

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded back-to-top"><i class="bi bi-arrow-up"></i></a> 

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>