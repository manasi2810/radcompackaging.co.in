  <?php include 'header.php';?>  

        <div class="container-fluid bg-primary py-5 bg-header" style="margin-bottom: 90px;">
            <div class="row py-5">
                <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                    <h1 class="display-4 text-white animated zoomIn">Caps And Clousers</h1>
                    <a href="" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="product.php" class="h5 text-white">Product</a>
                     <i class="far fa-circle text-white px-2"></i>
                    <a href="caps&clousers.php" class="h5 text-white">Caps And Clouser</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar End --> 

    <!-- Full Screen Search Start -->
    <div class="modal fade" id="searchModal" tabindex="-1">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content" style="background: rgba(9, 30, 62, .7);">
                <div class="modal-header border-0">
                    <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex align-items-center justify-content-center">
                    <div class="input-group" style="max-width: 600px;">
                        <input type="text" class="form-control bg-transparent border-primary p-3" placeholder="Type search keyword">
                        <button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Full Screen Search End --> 

    <!-- Blog Start -->
    <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <!-- Blog list Start -->
                <div class="col-lg-12">
                    <div class="row g-5">
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.1s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                  <img class="img-fluid" src="product/Flip top caps.jpg" alt="Flip top caps">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">BOSTON PET Bottles</a>-->
                                </div> 
                            </div>
                        </div>
                           <div class="col-md-4 wow slideInUp" data-wow-delay="0.3s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/apple ftc caps.jpg" alt="apple ftc caps">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Caps & CLosures</a>-->
                                </div> 
                            </div>
                        </div>
                          <div class="col-md-4 wow slideInUp" data-wow-delay="0.6s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/flip top caps 2.jpg" alt="flip top caps 2">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Glass Bottles</a>-->
                                </div>
                                
                            </div>
                        </div>
                          <div class="col-md-4 wow slideInUp" data-wow-delay="0.1s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/serum applicator.jpg" alt="serum applicator">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Caps & CLosures</a>-->
                                </div> 
                            </div>
                        </div>
                         <div class="col-md-4 wow slideInUp" data-wow-delay="0.3s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/disc top caps.jpg" alt="disc top caps">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Caps & CLosures</a>-->
                                </div> 
                            </div>
                        </div>
                          <div class="col-md-4 wow slideInUp" data-wow-delay="0.6s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/disc top caps 2.jpg" alt="disc top caps 2">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Glass Bottles</a>-->
                                </div>
                                
                            </div>
                        </div>
                          <div class="col-md-4 wow slideInUp" data-wow-delay="0.1s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/screw cap.jpg" alt="screw cap">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Caps & CLosures</a>-->
                                </div> 
                            </div>
                        </div>
                         <div class="col-md-4 wow slideInUp" data-wow-delay="0.3s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/comb applicator.jpg" alt="comb applicator">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Caps & CLosures</a>-->
                                </div> 
                            </div>
                        </div>
                          <div class="col-md-4 wow slideInUp" data-wow-delay="0.6s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/Plug.jpg" alt="Plug">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Glass Bottles</a>-->
                                </div>
                                
                            </div>
                        </div>
                         <div class="col-md-4 wow slideInUp" data-wow-delay="0.1s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/clild resistance caps.jpg" alt="clild resistance caps">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Caps & CLosures</a>-->
                                </div> 
                            </div>
                        </div>
                         <div class="col-md-4 wow slideInUp" data-wow-delay="0.3s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/measuring cup.jpg" alt="measuring cup">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Caps & CLosures</a>-->
                                </div> 
                            </div>
                        </div>
                          <div class="col-md-4 wow slideInUp" data-wow-delay="0.6s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/flip top caps 3.jpg" alt="flip top caps 3">
                                    <!--<a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="">Glass Bottles</a>-->
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
                <!-- Blog list End -->
    
                
            </div>
        </div>
    </div>
    <!-- Blog End -->


   <?php include 'footer.php';?>