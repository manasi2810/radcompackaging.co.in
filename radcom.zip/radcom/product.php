  <?php include 'header.php';?>  

        <div class="container-fluid bg-primary py-5 bg-header" style="margin-bottom: 90px;">
            <div class="row py-5">
                <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                    <h1 class="display-4 text-white animated zoomIn">Product</h1>
                    <a href="" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="" class="h5 text-white">Product</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Full Screen Search Start -->
    <div class="modal fade" id="searchModal" tabindex="-1">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content" style="background: rgba(9, 30, 62, .7);">
                <div class="modal-header border-0">
                    <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex align-items-center justify-content-center">
                    <div class="input-group" style="max-width: 600px;">
                        <input type="text" class="form-control bg-transparent border-primary p-3" placeholder="Type search keyword">
                        <button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Full Screen Search End -->


    <!-- Blog Start -->
    <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <!-- Blog list Start -->
                <div class="col-lg-12">
                    <div class="row g-5">
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.1s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                  <img class="img-fluid" src="product/PET bottle.jpg" style="height:280px; width:400px;" alt="Pet Bottles">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="pet bottle.php">PET Bottles</a>
                                </div>
                                <div class="p-4">  
                                    <h4 class="mb-3">PET Bottles</h4>
                                    <p>PET (Polyethylene Terephthalate) bottles are lightweight, durable, and eco-friendly packaging solutions, ideal for beverages, food, and personal care products. They are recyclable, transparent, and ensure product safety and freshness.</p>
                                    <a class="text-uppercase" href="pet bottle.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.3s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/hdpe tulip bottle.jpg" style="height:280px; width:400px;" alt="hdpe tulip bottle">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="hdpe bottle.php">HDPE Bottles</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">HDPE Bottles</h4>
                                    <p>HDPE (High-Density Polyethylene) bottles are strong, durable, and lightweight, perfect for storing chemicals, food, and beverages. They are recyclable, moisture-resistant, and offer excellent protection and safety for a wide range of products.</p>
                                    <a class="text-uppercase" href="hdpe bottle.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.6s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="product/Slant Jar.jpg" style="height:280px; width:400px;" alt="Slant Jar">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="jar.php">Jar</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">Jar</h4>
                                    <p>Jars are durable, versatile, and airtight containers used for storing food, cosmetics, and other household items. They offer secure, leak-proof storage and help maintain freshness, available in various materials like glass, plastic, or metal.</p>
                                    <a class="text-uppercase" href="jar.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.1s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="img/blog-3.jpg" alt="">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="caps&clousers.php">Caps & CLosures</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">Caps & CLosures</h4>
                                    <p>Caps and closures are essential components for sealing bottles, jars, and containers, ensuring product safety and freshness. Available in various designs and materials like plastic, metal, or aluminum, they provide secure, leak-proof seals to prevent spillage and contamination.</p>
                                    <a class="text-uppercase" href="caps&clousers.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.3s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="img/blog-1.jpg" alt="">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="pumps.php">Pumps</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">Pumps</h4>
                                    <p>Pumps are mechanisms designed to dispense liquids or creams from containers, providing controlled and easy application. Commonly used for cosmetics, lotions, and cleaning products, they offer convenience, hygiene, and help minimize waste by ensuring precise dosing.</p>
                                    <a class="text-uppercase" href="pumps.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.6s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="img/blog-2.jpg" alt="">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="glassbottle.php">Glass Bottles</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">Glass Bottles</h4>
                                    <p>Glass bottles are sturdy, non-reactive, eco-friendly, and visually appealing containers used for packaging beverages, perfumes, and food products. They offer excellent protection, preserve product integrity, provide a premium feel, are fully recyclable, and enhance brand presentation.</p>
                                    <a class="text-uppercase" href="glass bottle.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.1s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="img/blog-3.jpg" alt="">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="dropeer bottle.php">Dropper Bottles</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">Dropper Bottles</h4>
                                    <p>Dropper bottles are small, precision containers used for dispensing liquids in controlled amounts. Commonly used for essential oils, medications, cosmetics, and tinctures, they provide accurate dosing, minimize waste, ensure easy handling, and offer a convenient, hygienic application.</p>
                                    <a class="text-uppercase" href="dropper bottle.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 wow slideInUp" data-wow-delay="0.3s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="img/blog-1.jpg" alt="">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="airless bottle.php">Airless Bottle</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">Airless Bottles</h4>
                                    <p>Airless bottles are innovative packaging solutions designed to dispense creams, lotions, and serums without exposing the product to air. They maintain product freshness, prevent contamination, and ensure precise application, making them ideal for sensitive skincare and cosmetic products.</p>
                                    <a class="text-uppercase" href="airless bottle.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                         <div class="col-md-4 wow slideInUp" data-wow-delay="0.6s">
                            <div class="blog-item bg-light rounded overflow-hidden">
                                <div class="blog-img position-relative overflow-hidden">
                                    <img class="img-fluid" src="img/blog-1.jpg" alt="">
                                    <a class="position-absolute top-0 start-0 bg-primary text-white rounded-end mt-5 py-2 px-4" href="color cosmatics.php">Color Cosmatics</a>
                                </div>
                                <div class="p-4"> 
                                    <h4 class="mb-3">Color Cosmatics</h4>
                                    <p>Color cosmetics packaging is crafted to enhance the appeal and functionality of beauty products like lipsticks, eyeshadows, and blushes. Designed with vibrant, stylish finishes, it ensures product protection, ease of application, and a premium feel, while catering to diverse customer preferences.</p>
                                    <a class="text-uppercase" href="color cosmatics.php">Read More <i class="bi bi-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <!-- Blog list End -->
    
                
            </div>
        </div>
    </div>
    <!-- Blog End -->
   <?php include 'footer.php';?>